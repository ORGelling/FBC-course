#include "indent.ih"

void step_size(size_t const stepSize)
{
    indent_status::get_step_size(stepSize);
}
