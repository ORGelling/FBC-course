#include "indent.ih"

void indent_less()
{
    indent_status::change_indent(-1);
}
