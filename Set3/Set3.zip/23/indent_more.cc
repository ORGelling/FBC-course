#include "indent.ih"

void indent_more()
{
    indent_status::change_indent(+1);
}
