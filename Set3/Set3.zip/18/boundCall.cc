#include "main.ih"

void boundCall(size_t const argc, char const *argv[])
{
    show(combine(argc, argv));
}
