#include "arg.ih"

    // by 

Arg *Arg::s_instance = nullptr;
