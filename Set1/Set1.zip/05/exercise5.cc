#include <iostream>

using namespace std;

int main()
{
    cout << "new line: " << '\n';
    cout << "random character: " << '\q' << '\n';
    cout << "alert\aalert" << '\n';
    cout << "backspace\bbackspace" << '\n';
    cout << "formfeed\fformfeed" << '\n';
    cout << "Carriage return\rlalala"<< '\n';
    cout << "Octal\101Octal" << '\n';
    cout << "Hexadecimal\x41 Hexadecimal" << '\n';
    cout << "UnicodeValue\u03C0UnicodeValue" << '\n';
    cout << "UnicodeCharacter\U000003C0UnicodeCharacter" << '\n';
    cout << "end stuff" << '\n';
}
