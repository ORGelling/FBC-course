#include <iostream>                     // importing in-out-stream for cout

using namespace std;                    // adding namespace for ease

int main()                              // args not needed explicitly
{
    cout << "Hello World" << '\n';
}
