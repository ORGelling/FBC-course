#ifndef INCLUDED_DERIV2_
#define INCLUDED_DERIV2_

#include "../basic/basic.h"

class Deriv2: virtual public Basic
{};

#endif
