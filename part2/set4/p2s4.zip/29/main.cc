#include "main.ih"

int main()
{
    Multi multi;    //
}
