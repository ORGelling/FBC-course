#include "base.ih"

void Base::vHello(ostream &out) const
{
    out << "Hello from Base\n";
}
