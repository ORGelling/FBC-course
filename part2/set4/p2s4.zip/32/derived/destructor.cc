#include "derived.ih"

// overrides
Derived::~Derived()
{}
