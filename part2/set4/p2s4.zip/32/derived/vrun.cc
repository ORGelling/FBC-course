#include "derived.ih"

void Derived::v_run()
{
    cerr << "Derived::v_run is called\n";
}
