#include "derived.ih"

void Derived::v_prepare()
{
    cerr << "Derived::v_prepare is called\n";
}
