#include "derived.ih"

Derived::Derived()
{
    prepare();
    cout << "Derived::Derived done\n";
}
