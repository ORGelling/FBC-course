#include "request.ih"

Base &Request::base()
{
    return *d_base;
}
