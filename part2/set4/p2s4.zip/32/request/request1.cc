#include "request.ih"

Request::Request()
:
    d_base(new Derived())
{
    //
}
