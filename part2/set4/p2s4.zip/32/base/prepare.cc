#include "base.ih"

void Base::prepare()
{
    cout << "Base::prepare\n";
    v_prepare();
}
