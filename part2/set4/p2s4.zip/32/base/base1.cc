#include "base.ih"

Base::Base()
{
    //prepare();
    cout << "Base::Base\n";
}
