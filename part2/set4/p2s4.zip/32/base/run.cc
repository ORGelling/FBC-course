#include "base.ih"

void Base::run()
{
    cout << "Base::run\n";
    v_run();
}
