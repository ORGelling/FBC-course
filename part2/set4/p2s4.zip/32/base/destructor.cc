#include "base.ih"

// virtual
Base::~Base()
{}
