#include "handler/handler.h"
#include "processor/processor.h"

using namespace std;

int main()
{
    [[maybe_unused]] Handler hand;
    [[maybe_unused]] Processor process;
}
