#ifndef INCLUDED_PROCESSOR_
#define INCLUDED_PROCESSOR_

#include "../msgenum/msgenum.h"

class Processor: private MsgEnum        // Overengineered. See .ih
{
    public:
        Processor() = default;
        ~Processor() = default;
        
        // member functions
        
    private:
        // helpers etc
};
        
#endif
