#include "main.ih"

int main()
{
    TestFork forkThis;      // OG: yes yes, frivolous naming and all that

    forkThis.fork();
}
