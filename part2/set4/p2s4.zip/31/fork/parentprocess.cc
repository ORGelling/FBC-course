#include "fork.ih"

    // by 

void Fork::parentProcess()
{
    // empty on purpose, not inline since virtual
}
