#include "interactive.ih"

    // by 

Interactive::Interactive(string const &file)
:
    d_filename(file)
{}
