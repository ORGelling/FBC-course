//#include "random.ih"

    // by 

//Random::Random()
//:
//{}
