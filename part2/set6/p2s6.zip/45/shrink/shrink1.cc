#include "shrink.ih"

Shrink::Shrink(ostream &out, size_t size)
:
    d_out(out),
    d_str("1234567890qwertyuiop"),
    d_size(size)
{}
