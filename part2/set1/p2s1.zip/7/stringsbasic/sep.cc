#include "strings.ih"

string Strings::sep() const
{
    return d_sep;
}
