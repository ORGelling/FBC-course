#include "numbers.ih"

    // by 

Numbers::~Numbers()
{
    delete[] d_nums;
}
