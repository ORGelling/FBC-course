#include "numbers.ih"

    // by 

bool Numbers::compareSize(Numbers const &lhs, Numbers const &rhs)
{
    return lhs.d_size == rhs.d_size;
}
