#include "filter.ih"

Filter::Filter(istream &in)
:
    d_lines(in)
{}
