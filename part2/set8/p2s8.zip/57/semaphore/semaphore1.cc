#include "semaphore.ih"

    // by 

Semaphore::Semaphore(size_t nAvailable)
:
    d_nAvailable(nAvailable)
{}
