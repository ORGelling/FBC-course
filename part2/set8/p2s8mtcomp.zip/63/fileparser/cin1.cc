#include "fileparser.ih"

    // by 

void FileParser::cin()
{
    cin(std::cin);                      // use overload. This is here for
}                                       // the array of fn pointers to work
