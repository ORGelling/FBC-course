#include "workforce.ih"

    // by 

WorkForce::WorkForce()
:
    s_workForce(0),
    s_workToDo(0),
    s_adminReady(0),
    s_paperworkToDo(0)
{}
