#include "options.ih"

    // by 

Options *Options::s_instance = nullptr;     // initilising static member here
