#include "compilequeue.ih"

    // by 

CompileQueue::CompileQueue()
:
    d_finished(false)                   // I don't think this is even used?
{}
