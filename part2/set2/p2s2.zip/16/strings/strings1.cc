#include "strings.ih"

    // by 

Strings::Strings()
:                               // others are defult initialised
    d_str(0)
{
    cout << "default constructor\n";
    //throw 1;
}
