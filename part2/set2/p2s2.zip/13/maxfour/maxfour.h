#ifndef INCLUDED_MAXFOUR_
#define INCLUDED_MAXFOUR_

#include <iosfwd>

class MaxFour
{
    inline static size_t s_count;
    
    size_t d_number;
    
    public:
        MaxFour();
        ~MaxFour();
};

#endif
