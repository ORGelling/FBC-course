#include "tempfile.ih"

    // by 

fstream &TempFile::stream()
{
    return d_file;
}
