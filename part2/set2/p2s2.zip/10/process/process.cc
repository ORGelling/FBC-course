#include "process.ih"

Process::Process(Arg const &arg)
{
    cout << "processing\n";
    
    //throw "cannot read 'filename'"s;
}
