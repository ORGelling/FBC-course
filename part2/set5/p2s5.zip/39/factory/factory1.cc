#include "factory.ih"

Factory::Factory(size_t maxSide)
:
    d_sideSize(maxSide)
{}
