#include "storage.ih"

    // by 

Storage::Storage()
:
    d_finished(false)
{}
