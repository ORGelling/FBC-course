#include "client.ih"

    // by 

mutex Client::s_qMutex;
