#include "main.ih"

int main()
{
    Base base;
    caller(base);
}
