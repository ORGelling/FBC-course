#include "base.ih"

    // by 

Base::Base(ostream &out)
:
    d_out(out)
{
    //cerr << "called base ctor\n";
}
