#include "derived/derived.h"
#include <iostream>

using namespace std;

int main()
{
    Derived der("test.txt"s);
    //der << "New entry\n"; //
}
