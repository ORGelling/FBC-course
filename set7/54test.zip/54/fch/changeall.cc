#include "fch.ih"

    // by 

void Fch::changeAll()
{
    modify();
}
