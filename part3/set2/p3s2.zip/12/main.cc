#include "main.ih"

int main(int argc, char **argv)
{
    Simple<int> sim1;

    cout << sim1.get() << '\n';

    int val = 12;

    Simple<int *> sim2{ &val };

    cout << sim2.get() << '\n';
    
    int *intPtr = new int{};
    fun(intPtr);
}
