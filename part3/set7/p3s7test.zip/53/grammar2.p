%token VAR
%token NR
%left '+'
%left '*'
%right '-'

%%

expr:
    NR
|
    VAR
|
    '-' expr
|
    expr '+' expr
|
    expr '*' expr
|
    expr '[' expr ']'
;
