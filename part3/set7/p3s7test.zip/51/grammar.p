%token NUMBER

%left '-' '+'

%%

expr:
    NUMBER
|
    expr '+' expr
|
    expr '-' expr
;
