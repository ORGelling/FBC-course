%class-name Parser
%filenames parser
%scanner ../scanner/scanner.h
%token-path ../tokens/tokens.h

%baseclass-preinclude cmath
%stype double

%token NUMBER
%left '+'
%left '*' '/'
%right '^' '$' '-'

%%

input:
    // empty
|
    input line
;

line:
    '\n'
|
    exp '\n'
    {
        std::cout << '\t' << $1 << std::endl;
    }
;

exp:
    NUMBER
    {
        $$ = std::stod(d_scanner.matched());
    }
|
    '-' exp
    {
        $$ = -$2;
    }
|
    exp '+' exp
    {
        $$ = $1 + $3;
    }
|
    exp '-' exp
    {
        $$ = $1 - $3;
    }
|
    exp '*' exp
    {
        $$ = $1 * $3;
    }
|
    exp '/' exp
    {
        $$ = $1 / $3;
    }
|
    exp '^' exp
    {
        $$ = pow($1, $3);
    }
|
    '$' exp
    {
        $$ = sqrt($2);
    }
|
    '(' exp ')'
    {
        $$ = $2;
    }
;
