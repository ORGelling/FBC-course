#include "main.ih"

void fun(int first, int second)
{
    cout << "fun(" << first << ", " << second << ")\n";
}
