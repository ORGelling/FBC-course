#include "demo.ih"

Demo::Demo(string const &name)
:
    d_name(name)
{}
