#include "main.ih"

void incrementer(int &one, int &two, int &three)
{
    ++one;
    ++two;
    ++three;
}
