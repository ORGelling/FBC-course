#include "main.ih"

int main()
{
    function1();
    function2();
}
