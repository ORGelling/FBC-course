#ifndef INCLUDED_TEMPLATE_
#define INCLUDED_TEMPLATE_

template <typename Tp>
void address(Tp param)
{}

#endif
