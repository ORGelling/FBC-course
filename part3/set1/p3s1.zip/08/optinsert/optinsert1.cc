#include "optinsert.ih"

    // by 

OptInsert::OptInsert()
:
    d_insert(false),
    d_out(0)
{}
