#include "data.ih"

Data::Data()
:
    d_pimpl(new DataImp)
{}
