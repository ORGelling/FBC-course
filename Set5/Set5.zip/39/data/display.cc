#include "data.ih"

void Data::display() const
{
    d_pimpl->display();
}
