#include "data.ih"

bool Data::read()
{
    return d_pimpl->read();
}
