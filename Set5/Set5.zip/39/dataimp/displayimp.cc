#include "dataimp.ih"

void DataImp::display() const
{
    cout << "value is: " << d_value << '\n';
}
