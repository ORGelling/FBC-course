#include "copycat/copycat.h"
#include <iostream>

using namespace std;

int main()
{
    CopyCat envs;
}
