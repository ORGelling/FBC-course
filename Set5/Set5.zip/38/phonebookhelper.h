#ifndef INCLUDED_PHONEBOOK_HELPER_
#define INCLUDED_PHONEBOOK_HELPER_

#include "phonebook.h"

PhoneBook &phoneBook();

#endif
