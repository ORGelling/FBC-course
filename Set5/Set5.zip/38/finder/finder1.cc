#include "finder.ih"

Finder::Finder()
:
    d_pair(0),
    d_size(0)
{}
