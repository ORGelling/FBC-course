#include "main.ih"

Finder PhoneBook::s_finder;         // the phonebook's single Finder object
