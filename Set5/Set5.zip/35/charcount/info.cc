#include "charcount.ih"

    // by program 

CharCount::CharInfo const &CharCount::info() const
{
    return d_data;
}
