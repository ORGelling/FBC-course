#ifndef INCLUDED_SHOWCHAR_
#define INCLUDED_SHOWCHAR_

#include "charcount/charcount.h"

void showChar(CharCount::Char const ch);
std::string charOutput(unsigned char const ch);

#endif
