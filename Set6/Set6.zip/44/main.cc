#include "main.ih"

int main()
{
    Strings strings{ cin };
    
    for (size_t idx = 0, end = strings.size(); idx != end; ++idx)
        cout << "line " << idx + 1 << ": " << strings.at(idx) << '\n';

    cout << "current capacity: " << strings.capacity() << '\n';
}
