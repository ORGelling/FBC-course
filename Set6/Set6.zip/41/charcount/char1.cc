#include "charcount.ih"

CharCount::Char::Char(char const ch)
:
    ch(ch)
{}
