#include "charcount.ih"

CharCount::~CharCount()
{
    destroy();
}
