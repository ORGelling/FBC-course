#include "charcount.ih"

size_t CharCount::capacity() const
{
    return d_data.capacity;
}
