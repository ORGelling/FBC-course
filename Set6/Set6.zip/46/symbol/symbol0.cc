#include "symbol.ih"

    // by 

Symbol::Symbol()
:
    d_name(""),
    d_value(0)
{}
