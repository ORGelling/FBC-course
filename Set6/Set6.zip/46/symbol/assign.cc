#include "symbol.ih"

    // by 

void Symbol::assign(Value const &value)
{
    d_value = value;
}
