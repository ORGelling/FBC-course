#include "symbol.ih"

    // by 

Symbol::Symbol(string const &name, double doubleValue)
:
    d_name(name),
    d_value(doubleValue)
{}
