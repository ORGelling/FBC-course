#ifndef INCLUDED_ENUM_H_
#define INCLUDED_ENUM_H_

enum Token
{
    QUIT,
    CHAR,
    INT,
    DOUBLE,
    IDENT,
    ERROR,
};


#endif
