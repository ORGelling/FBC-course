#include "symtab.ih"

    // by 

Symtab::Symtab()
:
    d_data(rawPointers(d_capacity))
{}
