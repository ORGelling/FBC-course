#include "calculator.ih"

bool Calculator::done([[maybe_unused]] Value &ret)
{
    return false;
}
