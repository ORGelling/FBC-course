#include "calculator.ih"

    // by 

void Calculator::nextToken()
{
    if (d_ok)
        d_tokenizer.nextToken();
    
    // throw error?
}
