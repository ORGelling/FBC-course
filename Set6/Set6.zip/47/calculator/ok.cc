#include "calculator.ih"

    // by 

bool Calculator::ok()
{
    return d_ok;
}
