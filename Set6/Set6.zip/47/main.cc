#include "main.ih"

int main()
{
    Calculator beepboop;
    beepboop.run();
}
