#include "tokenizer.ih"

Tokenizer::Tokenizer(istream &in)
:
    d_in(in)
{}
