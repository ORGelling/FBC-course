#include "main.ih"

int main()
{
    Calculator lilRobotFriend;
    lilRobotFriend.run();
}
