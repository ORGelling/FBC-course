#include "line.ih"

Line::Line()
:
    d_position {string::npos}
{}
