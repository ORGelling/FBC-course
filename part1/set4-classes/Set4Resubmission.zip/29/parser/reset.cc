#include "parser.ih"

    // by 

bool Parser::reset()
{
    return d_line.getLine();
}
