#include "fch.ih"

    // by 

bool Fch::requestedN()
{
    return d_action == NO_CHANGES;
}
