#include "fch.ih"

    // by 

//void Fch::changeAll()
//{                                   // This is just an alias. We could have
//    modify();                       // called modify directly, but it's in
//}                                   // the header so I guess we're using it
