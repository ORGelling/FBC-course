#include "fch.ih"

    // by 

void Fch::insertLine() const
{
    cout << d_line << '\n';
}
