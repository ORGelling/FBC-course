#ifndef INCLUDED_ENUM_H_
#define INCLUDED_ENUM_H_

enum Action
{
    ASK,
    CHANGE_ALL,
    NO_CHANGES,
};


#endif
