#include "demo.ih"

    // by 

Demo::Demo()
//:
{
    cerr << "calling basic constructor.\n";
}
