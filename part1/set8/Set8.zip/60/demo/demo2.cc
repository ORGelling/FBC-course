#include "demo.ih"

    // by 

Demo::Demo(Demo const &other)
//:
{
    cerr << "calling copy constructor.\n";
}
