#include "demo.ih"

    // by 

Demo::Demo(Demo &&tmp)
//:
{
    cerr << "calling move constructor.\n";
}
