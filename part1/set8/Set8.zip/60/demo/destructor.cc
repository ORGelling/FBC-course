#include "demo.ih"

    // by 

Demo::~Demo()
{
    //cout << "\ncalling destructor\n";
}
