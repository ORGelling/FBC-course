#include "numbers.ih"

    // by 

Numbers::Numbers()
:
    d_size(0),
    d_data(nullptr)
{}
