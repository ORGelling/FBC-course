#include "numbers.ih"

    // by 

Numbers::Numbers(size_t count, int value)
:
    Numbers(count)
{
    setValues(value);
}
