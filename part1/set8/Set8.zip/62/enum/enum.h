#ifndef INCLUDED_ENUM_H_
#define INCLUDED_ENUM_H_

enum Type
{
    DOUBLE,
    STRING,
    VALUE,
};


#endif
