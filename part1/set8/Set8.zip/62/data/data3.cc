#include "data.ih"

    // by 

Data::Data(size_t const value)
:
    u_value(value)
{}
