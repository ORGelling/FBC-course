#include "data.ih"

    // by 

void Data::swapValDoub(Data &other)
{
    other.swapDoubVal(*this);
}
