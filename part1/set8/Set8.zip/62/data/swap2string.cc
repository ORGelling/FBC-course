#include "data.ih"

    // by 

void Data::swap2String(Data &other)
{
    u_word.swap(other.u_word);
}
