#include "data.ih"

    // by 

void Data::swap2Value(Data &other)
{
    std::swap(u_value, other.u_value);
}
