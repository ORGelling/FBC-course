#include "data.ih"

    // by 

Data::Data(string const &word)
:
    u_word(word)
{}
