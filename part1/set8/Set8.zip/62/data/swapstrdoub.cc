#include "data.ih"

    // by 

void Data::swapStrDoub(Data &other)
{
    other.swapDoubStr(*this);
}
