#include "data.ih"

    // by 

void Data::copyValue(Data const &tmp)
{
    u_value = tmp.u_value;
}
