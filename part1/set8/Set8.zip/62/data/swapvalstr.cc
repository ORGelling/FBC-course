#include "data.ih"

    // by 

void Data::swapValStr(Data &other)
{
    other.swapStrVal(*this);
}
