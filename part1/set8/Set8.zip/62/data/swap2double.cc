#include "data.ih"

    // by 

void Data::swap2Double(Data &other)
{
    std::swap(u_double, other.u_double);
}
