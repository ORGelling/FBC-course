#include "data.ih"

    // by 

void Data::destroyValue()               // Doesn't have to do anything 
{}                                      // since size_t is a basic type                         
