#include "data.ih"

    // by 

Data::~Data()
{}
