#include "data.ih"

    // by 

void Data::destroyString()
{
    u_word.string::~string();
}
