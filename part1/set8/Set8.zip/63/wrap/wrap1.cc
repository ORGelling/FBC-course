#include "wrap.ih"

    // by 

Wrap::Wrap(double *doubles)
:
    d_type(DOUBLE),
    d_data(doubles)
{}
