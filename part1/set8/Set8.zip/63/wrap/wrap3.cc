#include "wrap.ih"

    // by 

Wrap::Wrap(size_t const value)
:
    d_type(VALUE),
    d_data(value)
{}
