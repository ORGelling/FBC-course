#include "wrap.ih"

    // by 

Wrap::Wrap(string const &word)
:
    d_type(STRING),
    d_data(word)
{}
