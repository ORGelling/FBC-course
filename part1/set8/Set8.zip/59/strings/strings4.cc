#include "strings.ih"

Strings::Strings(istream &in)
:
    d_size(0),
    d_str(0),
    d_enlarge(&Strings::enlargeByCopy)
{
    string line;
    while (getline(in, line))
        add(line);
}
