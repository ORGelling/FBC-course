#ifndef HELPER_HEADER_
#define HELPER_HEADER_

#include "person.h"

void readIntoPerson(Person *personArray, size_t arraySize);
void writeFromPerson(Person const *personArray, size_t arraySize);

#endif
