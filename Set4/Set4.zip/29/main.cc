#include "parser/parser.h"

using namespace std;

int main()
{
    Parser parse;
    
    parse.reset();
}
