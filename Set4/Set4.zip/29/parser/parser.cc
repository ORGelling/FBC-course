#include "parser.ih"

    // by 

Parser::Parser()
:
    d_integral(true)
{}
