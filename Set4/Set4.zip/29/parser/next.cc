#include "parser.ih"

    // by number.cc 

string Parser::next()
{
    return d_line.next();
}
