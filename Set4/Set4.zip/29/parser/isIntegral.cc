#include "parser.ih"

    // by  

bool Parser::isIntegral() const
{
    return d_integral;
}
