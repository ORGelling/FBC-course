#include "calculator/calculator.h"

int main()
{
    Calculator lilRobotFriend;
    lilRobotFriend.run();
}
