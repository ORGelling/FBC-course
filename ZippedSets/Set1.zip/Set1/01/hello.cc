#include <iostream>                     // importing in-out-stream

using namespace std;                    // adding namespace

int main()                              // args not needed explicitly
{
    cout << "Hello World\n";
}
